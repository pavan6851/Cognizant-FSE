Run Commands:
javac *.java
java Main

Output:
Future Value after 5 years: ₹14693.28
