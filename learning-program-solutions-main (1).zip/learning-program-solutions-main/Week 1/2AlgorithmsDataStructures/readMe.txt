Run Commands:
javac *.java
java Main
