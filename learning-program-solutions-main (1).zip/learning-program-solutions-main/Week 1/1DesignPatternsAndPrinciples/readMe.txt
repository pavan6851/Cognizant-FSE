Run Commands:
javac *.java
java Main


Output:
Logger instance created.
LOG: Starting application...
LOG: Application running.
Both logger instances are the same. Singleton works!
