Run Commands:
javac *.java
java Main

Output:
Opening a Word document.
Opening a PDF document.
Opening an Excel document.
