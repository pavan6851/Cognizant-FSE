Run Commands:
mvn compile
mvn exec:java -Dexec.mainClass=LoggingExample

Output:
ERROR LoggingExample - This is an error message
WARN  LoggingExample - This is a warning message
