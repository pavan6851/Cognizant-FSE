Run Commands:
mvn test

Output:
Tests run: 2, Failures: 0, Errors: 0, Skipped: 0