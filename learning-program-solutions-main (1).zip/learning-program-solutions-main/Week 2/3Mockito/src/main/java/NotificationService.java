public interface NotificationService {
    void sendEmail(String recipient, String message);
}
