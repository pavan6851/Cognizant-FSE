Run Commands:
mvn test

Output:
Running AssertionsTest
Tests run: 1, Failures: 0, Errors: 0, Skipped: 0