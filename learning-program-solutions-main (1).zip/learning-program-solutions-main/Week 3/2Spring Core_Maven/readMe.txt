Run Commands:
mvn compile
mvn exec:java 
Ouput:
Book: Effective Java by Joshua Bloch
