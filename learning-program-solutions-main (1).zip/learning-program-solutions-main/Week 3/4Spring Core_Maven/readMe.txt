Run Commands:
mvn compile
mvn exec:java