package com.example.jpavshibernate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JpaVsHibernateApplication {
    public static void main(String[] args) {
        SpringApplication.run(JpaVsHibernateApplication.class, args);
    }
}
