Run Commands:
mvn spring-boot:run