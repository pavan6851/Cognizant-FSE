import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <h1>
          Welcome to first session of React
        </h1>
      </header>
    </div>
  );
}

export default App;
